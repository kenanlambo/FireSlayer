plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.emberwake.game"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.emberwake.game"
        minSdk = 26          // Android 8.0 and newer
        targetSdk = 36          // Android 16 (API 36): required by Google Play for new apps and updates since 31 Aug 2026
        versionCode = 155
        versionName = "1.55"
    }

    // One fixed key for every build, so a newer APK always installs over the previous one (and keeps your save).
    // This key lives in the project, which is fine for installing on your own phones. For Google Play, create a
    // separate private upload key in Android Studio (Build > Generate Signed App Bundle) and never put it in a public repo.
    signingConfigs {
        create("sideload") {
            storeFile = file("emberwake-sideload.jks")
            storePassword = "emberwake-sideload"
            keyAlias = "emberwake"
            keyPassword = "emberwake-sideload"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("sideload")
        }
        debug {
            signingConfig = signingConfigs.getByName("sideload")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    androidResources { noCompress += listOf("html") }
}
