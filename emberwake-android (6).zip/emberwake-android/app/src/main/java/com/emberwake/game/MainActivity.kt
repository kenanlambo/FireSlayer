package com.emberwake.game

import android.annotation.SuppressLint
import android.app.Activity
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.window.OnBackInvokedCallback
import android.window.OnBackInvokedDispatcher

/**
 * Hosts the Emberwake game (assets/index.html) in a full-screen WebView.
 * Progress is saved by the game in the WebView's local storage, which Android keeps
 * between launches. When the app goes to the background the game saves, and when it
 * comes back it adds the progress from offline grinding.
 */
class MainActivity : Activity() {

    private companion object { const val GAME_URL = "file:///android_asset/index.html" }

    private lateinit var web: WebView

    @SuppressLint("SetJavaScriptEnabled")
    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) // the battle never pauses
        if (Build.VERSION.SDK_INT < 35) {   // Android 15+ always draws edge-to-edge; bar colours only matter on older phones
            window.statusBarColor = Color.BLACK
            window.navigationBarColor = Color.BLACK
        }

        web = createWebView()
        setContentView(web)
        hideSystemBars()

        if (savedInstanceState != null) web.restoreState(savedInstanceState)
        else web.loadUrl(GAME_URL)

        // Android 13+ (and always on Android 16 when targeting API 36): the system back gesture
        // goes to this callback instead of onBackPressed().
        if (Build.VERSION.SDK_INT >= 33) {
            backCallback = OnBackInvokedCallback { handleBack() }
            onBackInvokedDispatcher.registerOnBackInvokedCallback(OnBackInvokedDispatcher.PRIORITY_DEFAULT, backCallback!!)
        }
    }

    private var backCallback: OnBackInvokedCallback? = null

    @SuppressLint("SetJavaScriptEnabled")
    private fun createWebView(): WebView {
        val web = WebView(this)
        web.setBackgroundColor(Color.BLACK)
        with(web.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true            // localStorage = save games
            databaseEnabled = true
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = true
            cacheMode = WebSettings.LOAD_DEFAULT
            loadWithOverviewMode = true
            useWideViewPort = true
            setSupportZoom(false)
            builtInZoomControls = false
            displayZoomControls = false
            textZoom = 100                      // ignore the phone's font-size setting so the layout stays intact
        }
        web.webViewClient = object : WebViewClient() {
            // If the phone runs out of memory, Android kills the WebView's renderer. Without this handler the whole
            // app would close ("crash"); instead we build a fresh WebView and reload the game (progress is saved).
            override fun onRenderProcessGone(view: WebView, detail: RenderProcessGoneDetail): Boolean {
                if (view !== this@MainActivity.web) return true
                (view.parent as? android.view.ViewGroup)?.removeView(view)
                view.destroy()
                this@MainActivity.web = createWebView()
                setContentView(this@MainActivity.web)
                hideSystemBars()
                this@MainActivity.web.loadUrl(GAME_URL)
                return true
            }
        }
        web.webChromeClient = WebChromeClient()
        web.overScrollMode = View.OVER_SCROLL_NEVER
        return web
    }


    private fun hideSystemBars() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.setDecorFitsSystemWindows(false)
            window.insetsController?.let {
                it.hide(WindowInsets.Type.systemBars())
                it.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    or View.SYSTEM_UI_FLAG_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                    or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN)
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    /** Back on Android 12 and older. */
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { handleBack() }

    /** Back closes an open menu first; with no menu open it sends the game to the background. */
    private fun handleBack() {
        web.evaluateJavascript(
            "(function(){ if (typeof UIX !== 'undefined' && UIX.sheet) { UIX.close(); return 'closed'; }" +
            " var m = document.getElementById('modal'); if (m && !m.hidden) { return 'modal'; } return 'none'; })()"
        ) { result ->
            if (result == "\"none\"") moveTaskToBack(true)
        }
    }

    override fun onPause() {
        web.evaluateJavascript("typeof UIX !== 'undefined' && UIX.save();", null)
        web.onPause()
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        web.onResume()
        hideSystemBars()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        web.saveState(outState)
    }

    override fun onDestroy() {
        if (Build.VERSION.SDK_INT >= 33) backCallback?.let { onBackInvokedDispatcher.unregisterOnBackInvokedCallback(it) }
        web.destroy()
        super.onDestroy()
    }
}
